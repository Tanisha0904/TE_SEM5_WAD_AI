import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'project';

  displayname = ""
  displayemail = ""
  displayphone = ""
  getDetails(name: string, email: string, phone: string) {
    this.displayemail = email;
    this.displayname = name;
    this.displayphone = phone;
  }
}
