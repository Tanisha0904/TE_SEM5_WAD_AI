<h1>AJAX POST METHOD</h1>
<?php

$username = $_POST['username'];
$email = $_POST['email'];

echo "<div> Hi,".$username."</div>";
echo "<div>Your email is: ".$email."</div>";


?>